# Red Hood: Gotham City
Open world Red Hood & Batman game in Gotham City.

## Controls
- WASD: Move / Drive
- Mouse: Aim
- Left click: Shoot
- E: Enter / Exit car
- 1: Play as Red Hood
- 2: Play as Batman
- P: Save
- O: Load

## Play Online
Upload this to GitHub Pages to play in your browser.
